Frontend:
1. Interface is having the code to accept the credentials and POST it to the backend.
2. Regarding connection with the backend: 