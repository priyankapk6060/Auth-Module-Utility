const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { findUserByUsername } = require('../models/userModel');

require('dotenv').config();


router.post('/login', async (req, res) => {
  const { username, password, redirectTo } = req.body;

  

  try {
    const user = await findUserByUsername(username);
    if (!user) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // ❗ Since password is in plain text, compare directly
    if (password !== user.password) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    const token = jwt.sign(
      { user_id: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN }
    );

    return res.status(200).json({ token });

  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
