const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv').config({ path: '../.env' });

const authRoutes = require('./routes/auth');


const app = express();
app.use(cors());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


// // ✅ Test route to check server connection
// try {
//   app.get('/api/test', (req, res) => {
//     res.json({ message: 'Backend is working!' });
//   });
// } catch (e) {
//   throw new Error("Cannot find test");
// }

app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Auth server running on port ${PORT}`);
});
